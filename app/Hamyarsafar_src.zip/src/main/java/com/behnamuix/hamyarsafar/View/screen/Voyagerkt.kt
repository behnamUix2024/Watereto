package com.behnamuix.hamyarsafar.View.screen

import androidx.compose.runtime.Composable
import cafe.adriel.voyager.core.screen.Screen

object MainTravelSc: Screen{
    @Composable
    override fun Content() {
        MainTravelContent()
    }

}
data class DetailTravelSc(var city: String,var explane:String, var link:String, var id:Int): Screen{
    @Composable
    override fun Content() {
        DetailTravelContent(city,explane,link,id)
    }

}
