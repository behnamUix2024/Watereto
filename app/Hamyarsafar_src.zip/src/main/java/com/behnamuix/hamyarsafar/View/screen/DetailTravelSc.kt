package com.behnamuix.hamyarsafar.View.screen

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import cafe.adriel.voyager.navigator.LocalNavigator
import cafe.adriel.voyager.navigator.currentOrThrow
import com.behnamuix.avacast.ui.theme.VazirFont
import com.behnamuix.avacast.ui.theme.VazirFontBold
import com.behnamuix.hamyarsafar.R

@Composable
fun DetailTravelContent(city_name: String, explane: String, link: String, id: Int) {
    var mf = Modifier
    var navigator= LocalNavigator.currentOrThrow
    var url = "https://fa.wikipedia.org/wiki/"
    var ctx = LocalContext.current
    Column(
        modifier = mf
            .fillMaxSize()
            .padding(start = 16.dp, end = 20.dp, top = 50.dp)

    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.End,
            modifier = mf.fillMaxWidth()
        ) {

                IconButton(
                    modifier = mf.padding(end = 200.dp),
                    onClick ={
                    navigator.pop()
                } ) {
                    Icon(
                        painter = painterResource(R.drawable.icon_arrow),
                        contentDescription = "",
                        tint = Color(0xFF3F51B5),
                        modifier = mf.size(32.dp)
                    )
                }

            Card(
                elevation = CardDefaults.elevatedCardElevation(8.dp),

                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Row(
                    modifier = Modifier
                        .padding(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        textAlign = TextAlign.End,
                        color = Color(0xFF3F51B5),
                        text = "همیارسفر",
                        fontFamily = VazirFontBold,
                        fontSize = 26.sp
                    )
                    Spacer(Modifier.width(10.dp))


                }
            }


        }
        Spacer(Modifier.height(20.dp))
        Column(

        ) {
            Image(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
                    .align(Alignment.CenterHorizontally)
                    .clip(RoundedCornerShape(20.dp)),
                painter = painterResource(id),
                contentScale = ContentScale.Crop,
                contentDescription = ""
            )
            Spacer(Modifier.height(20.dp))

            Text(
                modifier = Modifier
                    .fillMaxWidth(),
                style = TextStyle(textDirection = TextDirection.Rtl),
                text = city_name,
                fontFamily = VazirFontBold,
                fontSize = 38.sp,
                color = Color(0xFF3F51B5),
            )
            Spacer(Modifier.height(20.dp))

            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    modifier = Modifier
                        .fillMaxWidth(),
                    style = TextStyle(textDirection = TextDirection.Rtl),
                    text = explane,
                    fontFamily = VazirFont,
                    fontSize = 20.sp,
                    color = Color(0xFF7986CB),
                )
                Spacer(Modifier.height(20.dp))


            }
            Box(
                contentAlignment = Alignment.BottomEnd,
                modifier = Modifier
                    .padding(bottom = 80.dp)
                    .fillMaxSize()
            ) {
                Button(
                    elevation = ButtonDefaults.elevatedButtonElevation(8.dp),
                    modifier = Modifier
                        .fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE57373)),
                    shape = RoundedCornerShape(12.dp),
                    onClick = {
                        if (link.isEmpty()) {
                            ctx.startActivity(
                                Intent(
                                    Intent.ACTION_VIEW,
                                    Uri.parse(url + city_name)
                                )
                            )

                        } else {
                            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))

                        }
                    }) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            modifier = Modifier.padding(8.dp),
                            text = "اطلاعات بیشتر برای شهر $city_name",
                            fontFamily = VazirFontBold,
                            fontSize = 16.sp
                        )
                        Icon(
                            painter = painterResource(R.drawable.icon_earth),
                            contentDescription = "",
                            modifier = Modifier
                                .size(26.dp)
                        )

                    }
                }
            }
        }

    }
}