package com.behnamuix.hamyarsafar.View.screen

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import cafe.adriel.voyager.navigator.LocalNavigator
import cafe.adriel.voyager.navigator.currentOrThrow
import com.behnamuix.avacast.ui.theme.VazirFont
import com.behnamuix.avacast.ui.theme.VazirFontBold
import com.behnamuix.hamyarsafar.R

@Composable
fun MainTravelContent() {
    var city_name by remember { mutableStateOf("") }
    var explane by remember { mutableStateOf("") }
    var link by remember { mutableStateOf("") }
    var selectedImageResId by remember { mutableStateOf(R.drawable.paris_france) } // مقدار پیش‌فرض

    var mf = Modifier
    var pad_vertical = 12
    var pad_horizontal = 12
    var navigator = LocalNavigator.currentOrThrow
    Column(
        modifier = mf
            .fillMaxSize()
            .padding(start = 16.dp, end = 20.dp, top = 50.dp)

    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.End,
            modifier = mf.fillMaxWidth()
        ) {
            Card(
                elevation = CardDefaults.elevatedCardElevation(8.dp),

                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
               Row(
                   modifier = Modifier
                       .padding(4.dp),
                   verticalAlignment = Alignment.CenterVertically
               ) {
                   Text(
                       textAlign = TextAlign.End,
                       color = Color(0xFF3F51B5),
                       text = "همیارسفر",
                       fontFamily = VazirFontBold,
                       fontSize = 26.sp
                   )
                   Spacer(Modifier.width(10.dp))

                   Icon(
                       painter = painterResource(R.drawable.icon_location),
                       contentDescription = "",
                       tint = Color(0xFF3F51B5),
                       modifier = mf.size(32.dp)
                   )
               }
            }

        }



        Spacer(Modifier.height(20.dp))

        Column(
            verticalArrangement = Arrangement.spacedBy(pad_vertical.dp),
            modifier = mf.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(pad_horizontal.dp),

                ) {
                CityImage(
                    clicker = { selectedImageResId = R.drawable.australia_sydney },
                    img = R.drawable.australia_sydney,
                    lt = 20,
                    w = 220
                )
                CityImage(
                    clicker = {
                        selectedImageResId = R.drawable.berkeley_california
                    }, img = R.drawable.berkeley_california, rt = 20
                )
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(pad_horizontal.dp),
            ) {
                CityImage(
                    clicker = {
                        selectedImageResId = R.drawable.florence_italy
                    }, img = R.drawable.florence_italy
                )
                CityImage(
                    clicker = {
                        selectedImageResId = R.drawable.paris_france
                    }, img = R.drawable.paris_france
                )
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(pad_horizontal.dp),

                ) {
                CityImage(
                    clicker = {
                        selectedImageResId = R.drawable.singapore
                    }, img = R.drawable.singapore, lb = 20, w = 220
                )
                CityImage(
                    clicker = {
                        selectedImageResId = R.drawable.venice_italy
                    }, img = R.drawable.venice_italy, rb = 20
                )
            }
        }

        Spacer(Modifier.height(20.dp))


        Column(
            Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End
        ) {
            Row {
                MyTextField(
                    value = link,
                    onValueChange = { link = it },
                    "لینک گردشگری ",
                    width = 0.5f,
                    lines = 1,
                    R.drawable.icon_link
                )
                MyTextField(
                    value = city_name,
                    onValueChange = { city_name = it },
                    lbl = "نام شهر ",
                    width = 1f,
                    lines = 2,
                    R.drawable.icon_city
                )

            }
            MyTextField(
                value = explane,
                onValueChange = { explane = it },
                "توضیحات",
                lines = 4,
                icon = R.drawable.icon_clipboard
            )

            Button(
                elevation = ButtonDefaults.elevatedButtonElevation(8.dp),
                modifier = Modifier
                    .padding(top = 20.dp)
                    .align(Alignment.Start)
                    .fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3F51B5)),
                shape = RoundedCornerShape(12.dp),
                onClick = {
                    navigator.push(DetailTravelSc(city_name,explane, link, selectedImageResId))
                }) {
                Text(
                    modifier = Modifier.padding(8.dp),
                    text = "ادامه بده",
                    color = Color.White,
                    fontFamily = VazirFontBold,
                    fontSize = 16.sp
                )
            }
        }


    }

}

@Composable
fun MyTextField(
    value: String,
    onValueChange: (String) -> Unit,
    lbl: String,
    width: Float = 1f,
    lines: Int = 1,
    icon: Int = 0
) {

    OutlinedTextField(
        maxLines = lines, textStyle = TextStyle(
            color = Color.Black,textDirection = TextDirection.Rtl, fontSize = 16.sp, fontFamily = VazirFontBold
        ), modifier = Modifier
            .fillMaxWidth(width)
            .padding(8.dp),

        shape = RoundedCornerShape(12.dp), value = value, onValueChange = {
            onValueChange(it)
        }, label = {
            Text(
                modifier = Modifier.fillMaxWidth(),
                style = TextStyle(textDirection = TextDirection.Rtl),
                textAlign = TextAlign.Start,
                fontSize = 12.sp,
                fontFamily = VazirFont,
                color = Color.Gray,
                text = lbl
            )
        },
        trailingIcon = {
            Icon(
                painter = painterResource(icon),
                contentDescription = "",
                modifier = Modifier
                    .size(16.dp)
            )
        }

    )
}

@Composable
fun CityImage(
    clicker: (Int) -> Unit = {},
    img: Int,
    w: Int = 180,
    h: Int = 130,
    rb: Int = 4,
    lt: Int = 4,
    rt: Int = 4,
    lb: Int = 4
) {
    var alpha by remember { mutableStateOf(1f) }
    Image(
        painter = painterResource(img),
        contentDescription = "",
        contentScale = ContentScale.Crop,
        modifier = Modifier
            .alpha(alpha)
            .clickable(onClick = {
                alpha = 0.7f;
                clicker(img)
            })

            .width(w.dp)
            .height(h.dp)
            .clip(
                RoundedCornerShape(
                    topStart = lt.dp, bottomEnd = rb.dp, topEnd = rt.dp, bottomStart = lb.dp

                )
            )
    )

}
